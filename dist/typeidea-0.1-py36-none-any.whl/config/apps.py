from django.apps import AppConfig


class ConfigConfig(AppConfig):
    name = 'config'
